from bank_account import BankAccount
# Create a user class
class User:
    # Initialize the user's basic info
    def __init__(self, first_name: str, last_name: str, email: str):
        self.first_name = first_name
        self.last_name = last_name
        self.email = email
        self.account = BankAccount(0.2, 0)

    def make_deposit(self, amount):
        self.account.deposit(amount)
        return self

    def make_withdraw(self, amount):
        self.account.withdraw(amount)
        return self

    def display_user_balance(self):
        balance = self.account.display_account_info()
        user = f"{self.first_name} {self.last_name}"
        print(f"{user}, {balance}")
        return self

user1 = User("Tony", "Stark", "tony@mail.com").make_deposit(100)
user1.display_user_balance()
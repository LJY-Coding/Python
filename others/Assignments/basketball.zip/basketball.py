from players import players

class Player:
    team=[]
    # Challenge 1: Update the Constructor
    def __init__(self, players):
        self.name = players["name"]
        self.age = players["age"]
        self.position = players["position"]
        self.team = players["team"]
        # Player.team.append(self)

    # NINJA BONUS: Add a get_team(cls, team_list) @class method
    @classmethod
    def get_team(cls, team_list):
        for player in team_list:
            cls.team.append(player)
        return cls.team
    
# Create your Player instances here!
# player_jason = ???

# Challenge 2: Create instances using individual player dictionaries.
kevin = Player(players[0])
jason = Player(players[1])
kyrie = Player(players[2])

# Challenge 3: Make a list of Player instances from a list of dictionaries
new_team = []
for i in range(len(players)):
    new_team.append(Player(players[i]))

